package lab_4_4;

// Memory.java
public class Memory {
    private String type; // Например, DDR4
    private int size; // в ГБ

    public Memory(String type, int size) {
        this.type = type;
        this.size = size;
    }

    public String getType() {
        return type;
    }

    public int getSize() {
        return size;
    }

    @Override
    public String toString() {
        return "Память: " + type + " (размер: " + size + " ГБ)";
    }
}

