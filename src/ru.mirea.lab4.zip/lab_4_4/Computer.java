package lab_4_4;

// Computer.java
public class Computer {
    private ComputerBrand brand;
    private Processor processor;
    private Memory memory;
    private Monitor monitor;

    public Computer(ComputerBrand brand, Processor processor, Memory memory, Monitor monitor) {
        this.brand = brand;
        this.processor = processor;
        this.memory = memory;
        this.monitor = monitor;
    }

    public void displayInfo() {
        System.out.println("Компьютер: " + brand);
        System.out.println(processor);
        System.out.println(memory);
        System.out.println(monitor);
    }
}

