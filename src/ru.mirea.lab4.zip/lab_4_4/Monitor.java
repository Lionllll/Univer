package lab_4_4;

// Monitor.java
public class Monitor {
    private String resolution; // Например, 1920x1080
    private double size; // в дюймах

    public Monitor(String resolution, double size) {
        this.resolution = resolution;
        this.size = size;
    }

    public String getResolution() {
        return resolution;
    }

    public double getSize() {
        return size;
    }

    @Override
    public String toString() {
        return "Монитор: " + resolution + " (размер: " + size + " дюймов)";
    }
}
