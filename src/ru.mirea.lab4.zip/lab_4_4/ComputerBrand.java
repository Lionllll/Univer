package lab_4_4;

// ComputerBrand.java
public enum ComputerBrand {
    HUAWEI,
    HP,
    LENOVO,
    ASUS,
    APPLE;
}

