package lab_4_4;

// Processor.java
public class Processor {
    private String model;
    private double speed; // в ГГц

    public Processor(String model, double speed) {
        this.model = model;
        this.speed = speed;
    }

    public String getModel() {
        return model;
    }

    public double getSpeed() {
        return speed;
    }

    @Override
    public String toString() {
        return "Процессор: " + model + " (скорость: " + speed + " ГГц)";
    }
}

