package lab_4_4;

// Main.java
public class Main {
    public static void main(String[] args) {
        // Создаем процессор
        Processor processor = new Processor("Ryzen 5000", 3.5);
        // Создаем память
        Memory memory = new Memory("DDR4", 16);
        // Создаем монитор
        Monitor monitor = new Monitor("1920x1080", 24);

        // Создаем компьютер
        Computer computer = new Computer(ComputerBrand.HUAWEI, processor, memory, monitor);

        // Отображаем информацию о компьютере
        computer.displayInfo();
    }
}

