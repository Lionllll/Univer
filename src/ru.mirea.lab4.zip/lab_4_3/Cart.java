package lab_4_3;

import java.util.ArrayList;
import java.util.List;

// Cart.java
public class Cart {
    private List<Product> items;

    public Cart() {
        items = new ArrayList<>();
    }

    public void addProduct(Product product) {
        items.add(product);
    }

    public void displayCart() {
        if (items.isEmpty()) {
            System.out.println("Корзина пуста.");
        } else {
            System.out.println("Товары в корзине:");
            for (Product item : items) {
                System.out.println(item);
            }
        }
    }

    public double checkout() {
        double total = 0;
        for (Product item : items) {
            total += item.getPrice();
        }
        items.clear(); // Очищаем корзину после покупки
        return total;
    }
}

