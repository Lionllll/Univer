package lab_4_3;

// Main.java
public class Main {
    public static void main(String[] args) {
        Store store = new Store();
        store.run();
    }
}
