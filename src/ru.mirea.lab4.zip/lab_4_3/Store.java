package lab_4_3;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Store.java
public class Store {
    private List<Catalog> catalogs;
    private Cart cart;
    private User loggedInUser;

    public Store() {
        catalogs = new ArrayList<>();
        cart = new Cart();
        initStore();
    }

    private void initStore() {
        // Создаем каталоги и добавляем товары
        Catalog electronics = new Catalog("Электроника");
        electronics.addProduct(new Product("Смартфон", 699.99));
        electronics.addProduct(new Product("Ноутбук", 1299.99));
        catalogs.add(electronics);

        Catalog clothing = new Catalog("Одежда");
        clothing.addProduct(new Product("Футболка", 19.99));
        clothing.addProduct(new Product("Джинсы", 49.99));
        catalogs.add(clothing);
    }

    public void authenticateUser() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите логин: ");
        String username = scanner.nextLine();
        System.out.print("Введите пароль: ");
        String password = scanner.nextLine();
        // Простой способ проверки пользователя (можно расширить)
        if (username.equals("user") && password.equals("password")) {
            loggedInUser = new User(username, password);
            System.out.println("Аутентификация успешна!");
        } else {
            System.out.println("Неверный логин или пароль.");
        }
    }

    public void displayCatalogs() {
        System.out.println("Каталоги товаров:");
        for (int i = 0; i < catalogs.size(); i++) {
            System.out.println((i + 1) + ". " + catalogs.get(i).getName());
        }
    }

    public void displayProducts(int catalogIndex) {
        Catalog catalog = catalogs.get(catalogIndex);
        System.out.println("Товары в каталоге " + catalog.getName() + ":");
        for (int i = 0; i < catalog.getProducts().size(); i++) {
            System.out.println((i + 1) + ". " + catalog.getProducts().get(i));
        }
    }

    public void addToCart(int productIndex, int catalogIndex) {
        Product product = catalogs.get(catalogIndex).getProducts().get(productIndex);
        cart.addProduct(product);
        System.out.println("Товар добавлен в корзину: " + product);
    }

    public void checkout() {
        double total = cart.checkout();
        System.out.println("Сумма покупки: $" + total);
    }

    public void run() {
        Scanner scanner = new Scanner(System.in);
        authenticateUser();
        while (true) {
            displayCatalogs();
            System.out.print("Выберите каталог (или введите 0 для выхода): ");
            int catalogChoice = scanner.nextInt();
            if (catalogChoice == 0) break;

            displayProducts(catalogChoice - 1);
            System.out.print("Выберите товар для добавления в корзину (или введите 0 для возврата): ");
            int productChoice = scanner.nextInt();
            if (productChoice == 0) continue;

            addToCart(productChoice - 1, catalogChoice - 1);
            System.out.print("Хотите купить товары в корзине? (y/n): ");
            char checkoutChoice = scanner.next().charAt(0);
            if (checkoutChoice == 'y') {
                checkout();
                break;
            }
        }
        System.out.println("Спасибо за покупку!");
    }
}

