package lab_4_1;

// SeasonsExample.java
public class SeasonsExample {
    public static void main(String[] args) {
        // 1. Создаем переменную с любимым временем года
        Season favoriteSeason = Season.SUMMER;

        // 2. Распечатываем информацию о любимом времени года
        System.out.println("Любимое время года: " + favoriteSeason);
        System.out.println("Средняя температура: " + favoriteSeason.getAverageTemperature());

        // 3. Метод для вывода сообщения на основе времени года
        printFavoriteSeasonMessage(favoriteSeason);

        // 6. Цикл для распечатки всех времен года
        for (Season season : Season.values()) {
            System.out.println("Время года: " + season +
                    ", Средняя температура: " + season.getAverageTemperature() +
                    ", Описание: " + season.toString());
        }
    }

    // 4. Метод для обработки времени года с помощью switch
    public static void printFavoriteSeasonMessage(Season season) {
        switch (season) {
            case WINTER:
                System.out.println("Я люблю зиму");
                break;
            case SPRING:
                System.out.println("Я люблю весну");
                break;
            case SUMMER:
                System.out.println("Я люблю лето");
                break;
            case AUTUMN:
                System.out.println("Я люблю осень");
                break;
        }
    }
}

