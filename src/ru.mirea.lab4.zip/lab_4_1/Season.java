package lab_4_1;

// Season.java
enum Season {
    WINTER(-5), // Средняя температура для зимы
    SPRING(10), // Средняя температура для весны
    SUMMER(25), // Средняя температура для лета
    AUTUMN(15); // Средняя температура для осени

    private final int averageTemperature; // Переменная для хранения средней температуры

    // Конструктор
    Season(int averageTemperature) {
        this.averageTemperature = averageTemperature;
    }

    // Метод для получения средней температуры
    public int getAverageTemperature() {
        return averageTemperature;
    }

    // Метод для получения описания времени года
    public String getDescription() {
        return "Холодное время года";
    }

    // Переопределение метода для Лета
    @Override
    public String toString() {
        if (this == SUMMER) {
            return "Теплое время года";
        }
        return getDescription();
    }
}

