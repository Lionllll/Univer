package lab_4_2;

// Main.java
public class Main {
    public static void main(String[] args) {
        // Создаем массив одежды
        Clothes[] clothes = new Clothes[] {
                new TShirt(ClothingSize.M, 29.99, "Синий"),
                new Pants(ClothingSize.L, 49.99, "Черные"),
                new Skirt(ClothingSize.S, 39.99, "Красная"),
                new Tie(ClothingSize.M, 19.99, "Серый")
        };

        // Создаем экземпляр Atelier
        Atelier atelier = new Atelier();

        // Одеваем женщин и мужчин
        atelier.dressWomen(clothes);
        atelier.dressMan(clothes);
    }
}
