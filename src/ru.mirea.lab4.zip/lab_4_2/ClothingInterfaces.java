package lab_4_2;

// ClothingInterfaces.java
interface MenClothing {
    void dressMan();
}

interface WomenClothing {
    void dressWomen();
}

