package lab_4_2;

// ClothingSize.java
enum ClothingSize {
    XXS(32), // Детский размер
    XS(34),
    S(36),
    M(38),
    L(40);

    private final int euroSize; // Числовое значение euroSize

    // Конструктор
    ClothingSize(int euroSize) {
        this.euroSize = euroSize;
    }

    // Метод для получения euroSize
    public int getEuroSize() {
        return euroSize;
    }

    // Метод для получения описания размера
    public String getDescription() {
        if (this == XXS) {
            return "Детский размер";
        }
        return "Взрослый размер";
    }
}

