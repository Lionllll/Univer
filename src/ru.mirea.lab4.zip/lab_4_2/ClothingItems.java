package lab_4_2;

// ClothingItems.java
class TShirt extends Clothes implements MenClothing, WomenClothing {
    public TShirt(ClothingSize size, double price, String color) {
        super(size, price, color);
    }

    @Override
    public void dressMan() {
        System.out.println("Одеваем мужчину в футболку: " + getInfo());
    }

    @Override
    public void dressWomen() {
        System.out.println("Одеваем женщину в футболку: " + getInfo());
    }
}

class Pants extends Clothes implements MenClothing, WomenClothing {
    public Pants(ClothingSize size, double price, String color) {
        super(size, price, color);
    }

    @Override
    public void dressMan() {
        System.out.println("Одеваем мужчину в штаны: " + getInfo());
    }

    @Override
    public void dressWomen() {
        System.out.println("Одеваем женщину в штаны: " + getInfo());
    }
}

class Skirt extends Clothes implements WomenClothing {
    public Skirt(ClothingSize size, double price, String color) {
        super(size, price, color);
    }

    @Override
    public void dressWomen() {
        System.out.println("Одеваем женщину в юбку: " + getInfo());
    }
}

class Tie extends Clothes implements MenClothing {
    public Tie(ClothingSize size, double price, String color) {
        super(size, price, color);
    }

    @Override
    public void dressMan() {
        System.out.println("Одеваем мужчину в галстук: " + getInfo());
    }
}

