package lab_4_2;

// Clothes.java
abstract class Clothes {
    private ClothingSize size; // Размер одежды
    private double price; // Стоимость
    private final String color; // Цвет

    // Конструктор
    public Clothes(ClothingSize size, double price, String color) {
        this.size = size;
        this.price = price;
        this.color = color;
    }

    // Геттеры
    public ClothingSize getSize() {
        return size;
    }

    public double getPrice() {
        return price;
    }

    public String getColor() {
        return color;
    }

    // Метод для вывода информации о одежде
    public String getInfo() {
        return String.format("Размер: %s, EuroSize: %d, Цена: %.2f, Цвет: %s",
                size, size.getEuroSize(), price, color);
    }
}

