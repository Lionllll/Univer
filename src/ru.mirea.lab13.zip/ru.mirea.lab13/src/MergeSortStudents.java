import java.util.ArrayList;
import java.util.List;

class StudentInfo {
    int iDNumber;
    String name;

    public StudentInfo(int iDNumber, String name) {
        this.iDNumber = iDNumber;
        this.name = name;
    }

    @Override
    public String toString() {
        return "StudentInfo{" +
                "iDNumber=" + iDNumber +
                ", name='" + name + '\'' +
                '}';
    }
}

public class MergeSortStudents {
    public static void main(String[] args) {
        // Первый список студентов
        List<StudentInfo> list1 = new ArrayList<>();
        list1.add(new StudentInfo(3, "Alice"));
        list1.add(new StudentInfo(1, "Bob"));
        list1.add(new StudentInfo(5, "Charlie"));

        // Второй список студентов
        List<StudentInfo> list2 = new ArrayList<>();
        list2.add(new StudentInfo(2, "Diana"));
        list2.add(new StudentInfo(4, "Eve"));
        list2.add(new StudentInfo(6, "Frank"));

        System.out.println("Первый список:");
        printStudents(list1);

        System.out.println("Второй список:");
        printStudents(list2);

        // Объединяем и сортируем списки
        List<StudentInfo> mergedList = mergeAndSort(list1, list2);

        System.out.println("Объединенный и отсортированный список:");
        printStudents(mergedList);
    }

    public static List<StudentInfo> mergeAndSort(List<StudentInfo> list1, List<StudentInfo> list2) {
        List<StudentInfo> mergedList = new ArrayList<>(list1);
        mergedList.addAll(list2);
        return mergeSort(mergedList);
    }

    public static List<StudentInfo> mergeSort(List<StudentInfo> students) {
        if (students.size() <= 1) {
            return students;
        }

        int middle = students.size() / 2;
        List<StudentInfo> left = mergeSort(students.subList(0, middle));
        List<StudentInfo> right = mergeSort(students.subList(middle, students.size()));

        return merge(left, right);
    }

    public static List<StudentInfo> merge(List<StudentInfo> left, List<StudentInfo> right) {
        List<StudentInfo> merged = new ArrayList<>();
        int i = 0, j = 0;

        while (i < left.size() && j < right.size()) {
            if (left.get(i).iDNumber <= right.get(j).iDNumber) {
                merged.add(left.get(i));
                i++;
            } else {
                merged.add(right.get(j));
                j++;
            }
        }

        // Добавляем оставшиеся элементы
        while (i < left.size()) {
            merged.add(left.get(i));
            i++;
        }
        while (j < right.size()) {
            merged.add(right.get(j));
            j++;
        }

        return merged;
    }

    public static void printStudents(List<StudentInfo> students) {
        students.forEach(System.out::println);
    }
}