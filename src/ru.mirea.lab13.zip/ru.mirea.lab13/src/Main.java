import java.util.Arrays;
public class Main {
    public static void main(String[] args) {
        // Создаем массив студентов
        Student[] students = {
                new Student(3, "Alice"),
                new Student(1, "Bob"),
                new Student(4, "Charlie"),
                new Student(2, "Diana")
        };

        System.out.println("До сортировки:");
        printStudents(students);

        // Сортируем массив методом вставок
        insertionSort(students);

        System.out.println("После сортировки:");
        printStudents(students);
    }

    public static void insertionSort(Student[] array) {
        for (int i = 1; i < array.length; i++) {
            Student key = array[i];
            int j = i - 1;

            // Сравниваем и перемещаем элементы
            while (j >= 0 && array[j].iDNumber > key.iDNumber) {
                array[j + 1] = array[j];
                j--;
            }
            array[j + 1] = key;
        }
    }

    public static void printStudents(Student[] students) {
        Arrays.stream(students).forEach(System.out::println);
    }
}

