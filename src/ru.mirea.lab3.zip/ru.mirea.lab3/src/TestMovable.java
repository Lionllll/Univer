package ru.mirea.lab3;

public class TestMovable {
    public static void main(String[] args) {
        // Тестирование MovablePoint
        MovablePoint point = new MovablePoint(0, 0, 2, 2);
        System.out.println("Initial position: " + point);
        point.moveUp();
        System.out.println("After moving up: " + point);
        point.moveRight();
        System.out.println("After moving right: " + point);

        // Тестирование MovableCircle
        MovableCircle circle = new MovableCircle(0, 0, 1, 1, 5);
        System.out.println("Initial position of circle: " + circle);
        circle.moveUp();
        System.out.println("After moving circle up: " + circle);
        circle.moveRight();
        System.out.println("After moving circle right: " + circle);
    }
}

