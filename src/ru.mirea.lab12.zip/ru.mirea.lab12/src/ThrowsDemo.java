import java.util.Scanner;

public class ThrowsDemo {

    public void getKey() {
        Scanner myScanner = new Scanner(System.in);
        String key = null;

        while (true) {
            System.out.print("Enter a key: ");
            key = myScanner.next();

            try {
                printDetails(key);
                break; // Выход из цикла, если ввод корректен
            } catch (Exception e) {
                System.out.println("Caught an exception: " + e.getMessage());
                System.out.println("Please try again."); // Предложение повторить ввод
            }
        }

        myScanner.close(); // Закрытие сканера
    }

    public void printDetails(String key) throws Exception { // Объявляем throws
        String message = getDetails(key);
        System.out.println(message);
    }

    private String getDetails(String key) throws Exception { // Объявляем throws
        if (key == null || key.equals("")) { // Проверка на null и пустую строку
            throw new Exception("Key set to empty string or null");
        }
        return "data for " + key;
    }

    public static void main(String[] args) {
        ThrowsDemo demo = new ThrowsDemo();
        demo.getKey(); // Ввод ключа
    }
}