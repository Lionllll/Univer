import java.util.Scanner;

public class Exception2 {
    public void exceptionDemo() {
        Scanner myScanner = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        String intString = myScanner.next();

        try {
            int i = Integer.parseInt(intString);
            System.out.println(2 / i);
        } catch (ArithmeticException e) {
            System.out.println("Attempted division by zero");
        } catch (NumberFormatException e) {
            System.out.println("Invalid input, not an integer");
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        } finally {
            myScanner.close(); // Закрытие сканера
            System.out.println("Scanner closed.");
        }
    }

    public static void main(String[] args) {
        // Инстанцирование класса Exception2
        Exception2 exceptionExample = new Exception2();

        // Вызов метода exceptionDemo
        exceptionExample.exceptionDemo();
    }
}