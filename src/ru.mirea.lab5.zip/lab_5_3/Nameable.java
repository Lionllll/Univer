package lab_5_3;

public interface Nameable {
    String getName();
}
