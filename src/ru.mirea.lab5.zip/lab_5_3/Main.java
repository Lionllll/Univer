package lab_5_3;

public class Main {
    public static void main(String[] args) {
        // Создаем объекты разных классов, реализующих интерфейс Nameable
        Nameable planet = new Planet("Earth");
        Nameable car = new Car("Tesla Model S");
        Nameable animal = new Animal("Tiger");

        // Проверка работы метода getName() для каждого объекта
        System.out.println("Planet name: " + planet.getName());
        System.out.println("Car name: " + car.getName());
        System.out.println("Animal name: " + animal.getName());
    }
}
