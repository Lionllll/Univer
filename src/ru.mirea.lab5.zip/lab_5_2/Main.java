package lab_5_2;

public class Main {
    public static void main(String[] args) {
        // Создаем движущийся прямоугольник
        MovableRectangle rectangle = new MovableRectangle(0, 0, 4, 4, 2, 2);
        System.out.println("Initial Rectangle: " + rectangle);
        rectangle.moveUp();
        System.out.println("After moving up: " + rectangle);
        rectangle.moveLeft();
        System.out.println("After moving left: " + rectangle);

        // Попробуем создать прямоугольник с разными скоростями
        MovableRectangle rectangleWithDifferentSpeed = new MovableRectangle(0, 0, 4, 4, 2, 3);
        System.out.println("\nRectangle with different speeds: " + rectangleWithDifferentSpeed);
        rectangleWithDifferentSpeed.moveUp();  // Должно вывести сообщение об ошибке
    }
}
