package lab_5_1;

public class Main {
    public static void main(String[] args) {
        // Создаем объект MovablePoint
        MovablePoint point = new MovablePoint(0, 0, 2, 3);
        System.out.println("Initial Point: " + point);
        point.moveUp();
        System.out.println("After moving up: " + point);
        point.moveRight();
        System.out.println("After moving right: " + point);

        // Создаем объект MovableCircle
        MovableCircle circle = new MovableCircle(5, 5, 1, 1, 10);
        System.out.println("\nInitial Circle: " + circle);
        circle.moveDown();
        System.out.println("After moving down: " + circle);
        circle.moveLeft();
        System.out.println("After moving left: " + circle);
    }
}

