public interface StringProcessable {

    int countCharacters(String s);

    String oddPositionCharacters(String s);

    String invertString(String s);
}