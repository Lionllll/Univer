public class Main {
    public static void main(String[] args) {
        ProcessStrings ps = new ProcessStrings();

        String testString = "Hello World!";

        System.out.println("Количество символов: " + ps.countCharacters(testString));
        System.out.println("Символы на нечетных позициях: " + ps.oddPositionCharacters(testString));
        System.out.println("Инвертированная строка: " + ps.invertString(testString));
    }
}