class ProcessStrings implements StringProcessable {

    @Override
    public int countCharacters(String s) {
        return s.length();
    }

    @Override
    public String oddPositionCharacters(String s) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            if (i % 2 != 0) { // Нечетные позиции (1, 3, 5...)
                result.append(s.charAt(i));
            }
        }
        return result.toString();
    }

    @Override
    public String invertString(String s) {
        return new StringBuilder(s).reverse().toString();
    }
}