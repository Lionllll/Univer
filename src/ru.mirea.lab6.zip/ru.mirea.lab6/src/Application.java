public class Application {

    public static void main(String[] args) {
        // Тестирование MovablePoint и MovableRectangle
        testMovableClasses();

        // Тестирование MathFunc
        testMathFunc();

        // Тестирование ProcessStrings
        testStringProcessing();
    }

    private static void testMovableClasses() {
        System.out.println("Testing MovablePoint and MovableRectangle:");

        MovablePoint topLeft = new MovablePoint(0, 0, 2);
        MovablePoint bottomRight = new MovablePoint(4, 4, 2);

        System.out.println("Initial positions:");
        System.out.println("Top Left: " + topLeft);
        System.out.println("Bottom Right: " + bottomRight);

        MovableRectangle rectangle = new MovableRectangle(topLeft, bottomRight);

        rectangle.moveUp();
        System.out.println("After moving up:");
        System.out.println(rectangle);

        rectangle.moveRight();
        System.out.println("After moving right:");
        System.out.println(rectangle);
    }

    private static void testMathFunc() {
        System.out.println("\nTesting MathFunc:");

        MathFunc mathFunc = new MathFunc();

        double base = 2.0;
        double exponent = 3.0;
        System.out.printf("Power of %.1f raised to %.1f: %.1f%n", base, exponent, mathFunc.power(base, exponent));

        double real = 3.0;
        double imaginary = 4.0;
        System.out.printf("Modulus of complex number (%.1f + %.1fi): %.1f%n", real, imaginary, mathFunc.modulus(real, imaginary));
    }

    private static void testStringProcessing() {
        System.out.println("\nTesting ProcessStrings:");

        ProcessStrings processStrings = new ProcessStrings();

        String testString = "Hello World";

        System.out.printf("Original string: %s%n", testString);
        System.out.printf("Character count: %d%n", processStrings.countCharacters(testString));
        System.out.printf("Odd position characters: %s%n", processStrings.oddPositionCharacters(testString));
        System.out.printf("Inverted string: %s%n", processStrings.invertString(testString));
    }
}