public interface MathCalculable {
    double power(double base, double exponent);

    double modulus(double real, double imaginary);

    double PI = 3.141592653589793; // Константа PI
}