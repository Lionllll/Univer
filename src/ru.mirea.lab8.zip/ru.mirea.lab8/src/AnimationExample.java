import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AnimationExample extends JPanel implements ActionListener {
    private Image[] frames;
    private int currentFrame;

    public AnimationExample() {
        frames = new Image[5]; // Предполагаем наличие 5 кадров
        for (int i = 0; i < frames.length; i++) {
            frames[i] = Toolkit.getDefaultToolkit().getImage("frame" + i + ".png"); // Замените на ваши кадры
        }

        Timer timer = new Timer(100, this); // Смена кадров каждые 100 мс
        timer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (frames[currentFrame] != null) {
            g.drawImage(frames[currentFrame], 0, 0, this);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        currentFrame++;
        if (currentFrame >= frames.length) {
            currentFrame = 0; // Начинаем с первого кадра
        }
        repaint();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Animation Example");

        AnimationExample panel = new AnimationExample();

        frame.add(panel);
        frame.setSize(500, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}