import javax.swing.*;
import java.awt.*;
import java.util.Scanner;

public class ImageDisplay {
    public static void main(String[] args) {
        // Сканер для ввода пути к изображению
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите путь к изображению:");

        // Считываем путь к изображению
        String imagePath = scanner.nextLine();

        // Создаем главное окно
        JFrame frame = new JFrame("Image Viewer");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 600);

        // Панель для отображения изображения
        JPanel imagePanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Загружаем изображение
                Image image = new ImageIcon(imagePath).getImage();

                if (image != null) {
                    // Рисуем изображение, масштабируя его под размеры окна
                    g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
                } else {
                    // Сообщение об ошибке, если изображение не загружено
                    g.drawString("Изображение не найдено или путь неверный.", 10, 20);
                }
            }
        };

        frame.add(imagePanel);
        frame.setVisible(true);
    }
}
