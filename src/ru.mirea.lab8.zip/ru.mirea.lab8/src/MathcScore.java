import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MathcScore {
    private static int milanScore = 0;
    private static int madridScore = 0;
    private static String lastScorer = "N/A";
    private static String winner = "DRAW";

    public static void main(String[] args) {
        JFrame frame = new JFrame("Match Score");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

        JButton milanButton = new JButton("AC Milan");
        JButton madridButton = new JButton("Real Madrid");
        JLabel resultLabel = new JLabel("Result: 0 X 0");
        JLabel lastScorerLabel = new JLabel("Last Scorer: N/A");
        JLabel winnerLabel = new JLabel("Winner: DRAW");

        milanButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                milanScore++;
                lastScorer = "AC Milan";
                updateLabels(resultLabel, lastScorerLabel, winnerLabel);
            }
        });

        madridButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                madridScore++;
                lastScorer = "Real Madrid";
                updateLabels(resultLabel, lastScorerLabel, winnerLabel);
            }
        });

        JPanel panel = new JPanel();
        panel.add(milanButton);
        panel.add(madridButton);
        panel.add(resultLabel);
        panel.add(lastScorerLabel);
        panel.add(winnerLabel);

        frame.getContentPane().add(panel);
        frame.setVisible(true);
    }

    private static void updateLabels(JLabel result, JLabel lastScorerLabel, JLabel winnerLabel) {
        result.setText("Result: " + milanScore + " X " + madridScore);
        lastScorerLabel.setText("Last Scorer: " + lastScorer);

        if (milanScore > madridScore) {
            winner = "AC Milan";
        } else if (madridScore > milanScore) {
            winner = "Real Madrid";
        } else {
            winner = "DRAW";
        }

        winnerLabel.setText("Winner: " + winner);
    }
}