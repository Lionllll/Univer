import java.util.Scanner;

public class PalindromeCheck {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите слово, состоящее только из строчных латинских букв: ");
        String word = scanner.nextLine();

        if (isPalindrome(word, 0, word.length() - 1)) {
            System.out.println("YES");
        } else {
            System.out.println("NO");
        }
    }

    public static boolean isPalindrome(String word, int left, int right) {
        if (left >= right) return true;
        if (word.charAt(left) != word.charAt(right)) return false;
        return isPalindrome(word, left + 1, right - 1);
    }
}