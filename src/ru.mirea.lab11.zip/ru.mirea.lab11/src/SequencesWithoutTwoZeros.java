import java.util.Scanner;

public class SequencesWithoutTwoZeros {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите количество нулей a: ");
        int a = scanner.nextInt();

        System.out.print("Введите количество единиц b: ");
        int b = scanner.nextInt();

        System.out.println("Количество последовательностей: " + countSequences(a, b));
    }

    public static int countSequences(int a, int b) {
        if (a == 0) return 1; // Все единицы
        if (b == 0) return a == 1 ? 1 : 0; // Один ноль или больше - недопустимо

        // Считаем количество последовательностей с одним нулем и без двух подряд
        return countSequences(a - 1, b) + countSequences(a, b - 1);
    }
}