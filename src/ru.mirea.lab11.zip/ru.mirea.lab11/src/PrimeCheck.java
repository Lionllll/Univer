import java.util.Scanner;

public class PrimeCheck {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите натуральное число n (n > 1): ");
        int n = scanner.nextInt();

        if (isPrime(n, 2)) {
            System.out.println("YES");
        } else {
            System.out.println("NO");
        }
    }

    public static boolean isPrime(int n, int divisor) {
        if (n <= 1) return false;
        if (divisor * divisor > n) return true; // Если делитель больше корня из n
        if (n % divisor == 0) return false; // Если n делится на divisor
        return isPrime(n, divisor + 1); // Рекурсивный вызов с увеличенным делителем
    }
}