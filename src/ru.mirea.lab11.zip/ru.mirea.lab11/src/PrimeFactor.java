import java.util.Scanner;

public class PrimeFactor {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите натуральное число n (n > 1): ");
        int n = scanner.nextInt();

        System.out.print("Простые множители числа " + n + ": ");
        printPrimeFactors(n, 2);
    }

    public static void printPrimeFactors(int n, int divisor) {
        if (n < 2) return;
        while (n % divisor == 0) {
            System.out.print(divisor + " ");
            n /= divisor;
        }
        printPrimeFactors(n, divisor + 1);
    }
}