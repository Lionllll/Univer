import java.util.ArrayList;

public class ArrayListTest {
    public static void main(String[] args) {
        // Создаем ArrayList
        ArrayList<String> fruits = new ArrayList<>();

        // Добавляем элементы в список
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Cherry");
        System.out.println("Список после добавления элементов: " + fruits);

        // Вставляем элемент в определённую позицию
        fruits.add(1, "Orange");
        System.out.println("Список после вставки Orange на позицию 1: " + fruits);

        // Удаляем элемент по индексу
        fruits.remove(2);
        System.out.println("Список после удаления элемента с позиции 2: " + fruits);

        // Удаляем элемент по значению
        fruits.remove("Apple");
        System.out.println("Список после удаления Apple: " + fruits);

        // Проверяем, содержит ли список определённый элемент
        boolean containsBanana = fruits.contains("Banana");
        System.out.println("Список содержит Banana? " + containsBanana);

        // Получаем элемент по индексу
        String fruitAtIndex1 = fruits.get(1);
        System.out.println("Элемент на позиции 1: " + fruitAtIndex1);

        // Получаем размер списка
        int size = fruits.size();
        System.out.println("Размер списка: " + size);

        // Итерируем по элементам с использованием цикла
        System.out.println("Итерация по списку с использованием цикла for:");
        for (String fruit : fruits) {
            System.out.println("- " + fruit);
        }

        // Очищаем список
        fruits.clear();
        System.out.println("Список после очистки: " + fruits);

        // Проверяем, пуст ли список
        boolean isEmpty = fruits.isEmpty();
        System.out.println("Список пуст? " + isEmpty);
    }
}
