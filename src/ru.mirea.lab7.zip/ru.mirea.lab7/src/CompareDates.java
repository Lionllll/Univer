import java.util.Calendar;
import java.util.Scanner;

public class CompareDates {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Получение текущей даты
        Calendar currentCalendar = Calendar.getInstance();

        System.out.print("Введите дату (гггг-мм-дд): ");
        String inputDate = scanner.nextLine();

        String[] dateParts = inputDate.split("-");
        int year = Integer.parseInt(dateParts[0]);
        int month = Integer.parseInt(dateParts[1]); // Месяцы от 1 до 12
        int day = Integer.parseInt(dateParts[2]);

        // Проверка корректности месяца и дня
        if (month < 1 || month > 12) {
            System.out.println("Ошибка: месяц должен быть от 1 до 12.");
            return;
        }

        // Проверка корректности дня в зависимости от месяца
        if (day < 1 || day > getMaxDaysInMonth(month, year)) {
            System.out.println("Ошибка: некорректный день для указанного месяца.");
            return;
        }

        Calendar userCalendar = Calendar.getInstance();
        userCalendar.set(year, month - 1, day); // Установка даты (месяцы начинаются с 0)

        if (userCalendar.after(currentCalendar)) {
            System.out.println("Введенная дата позже текущей даты.");
        } else if (userCalendar.before(currentCalendar)) {
            System.out.println("Введенная дата раньше текущей даты.");
        } else {
            System.out.println("Введенная дата совпадает с текущей датой.");
        }
    }

    // Метод для получения максимального количества дней в месяце
    private static int getMaxDaysInMonth(int month, int year) {
        switch (month) {
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                return 31; // Январь, Март, Май, Июль, Август, Октябрь, Декабрь
            case 4: case 6: case 9: case 11:
                return 30; // Апрель, Июнь, Сентябрь, Ноябрь
            case 2:
                // Февраль
                if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
                    return 29; // Високосный год
                } else {
                    return 28; // Невисокосный год
                }
            default:
                return -1; // Неверный месяц
        }
    }
}