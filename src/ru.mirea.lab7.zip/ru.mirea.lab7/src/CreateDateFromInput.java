import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class CreateDateFromInput {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите год: ");
        int year = scanner.nextInt();

        System.out.print("Введите месяц (от 1 до 12): ");
        int month = scanner.nextInt(); // Месяцы от 1 до 12

        // Проверка корректности месяца
        if (month < 1 || month > 12) {
            System.out.println("Ошибка: месяц должен быть от 1 по 12.");
            return;
        }

        System.out.print("Введите день: ");
        int day = scanner.nextInt();

        // Проверка корректности дня в зависимости от месяца
        if (day < 1 || day > getMaxDaysInMonth(month, year)) {
            System.out.println("Ошибка: некорректный день для указанного месяца.");
            return;
        }

        System.out.print("Введите часы (0-23): ");
        int hour = scanner.nextInt();

        // Проверка корректности часов
        if (hour < 0 || hour > 23) {
            System.out.println("Ошибка: часы должны быть от 0 по 23.");
            return;
        }

        System.out.print("Введите минуты (0-59): ");
        int minute = scanner.nextInt();

        // Проверка корректности минут
        if (minute < 0 || minute > 59) {
            System.out.println("Ошибка: минуты должны быть от 0 по 59.");
            return;
        }

        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month - 1, day, hour, minute); // Установка даты и времени

        Date dateFromInput = calendar.getTime();

        System.out.println("Созданная дата: " + dateFromInput);
    }

    // Метод для получения максимального количества дней в месяце
    private static int getMaxDaysInMonth(int month, int year) {
        switch (month) {
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                return 31; // Январь, Март, Май, Июль, Август, Октябрь, Декабрь
            case 4: case 6: case 9: case 11:
                return 30; // Апрель, Июнь, Сентябрь, Ноябрь
            case 2:
                // Февраль
                if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
                    return 29; // Високосный год
                } else {
                    return 28; // Невисокосный год
                }
            default:
                return -1; // Неверный месяц
        }
    }
}