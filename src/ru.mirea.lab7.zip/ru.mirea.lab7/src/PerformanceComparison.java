import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class PerformanceComparison {
    public static void main(String[] args) {
        final int SIZE = 100000;

        // Сравнение ArrayList по времени вставки
        List<Integer> arrayList = new ArrayList<>();
        long startTimeArrayListAdd = System.currentTimeMillis();

        for (int i = 0; i < SIZE; i++) {
            arrayList.add(i);
        }

        long endTimeArrayListAdd = System.currentTimeMillis();

        // Сравнение LinkedList по времени вставки
        List<Integer> linkedList = new LinkedList<>();
        long startTimeLinkedListAdd = System.currentTimeMillis();

        for (int i = 0; i < SIZE; i++) {
            linkedList.add(i);
        }

        long endTimeLinkedListAdd = System.currentTimeMillis();

        System.out.println("Время вставки в ArrayList: " + (endTimeArrayListAdd - startTimeArrayListAdd) + " мс");
        System.out.println("Время вставки в LinkedList: " + (endTimeLinkedListAdd - startTimeLinkedListAdd) + " мс");
    }
}