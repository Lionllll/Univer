import java.text.SimpleDateFormat;
import java.util.Date;

public class TaskInfo {
    public static void main(String[] args) {
        String developerSurname = "Иванов"; // Замените на свою фамилию
        Date currentDate = new Date(); // Получение текущей даты и времени

        // Форматирование даты и времени
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        System.out.println("Фамилия разработчика: " + developerSurname);
        System.out.println("Дата и время получения задания: " + sdf.format(currentDate));

        // Предположим, что задание сдано через 2 дня
        Date submissionDate = new Date(currentDate.getTime() + 2 * 24 * 60 * 60 * 1000);
        System.out.println("Дата и время сдачи задания: " + sdf.format(submissionDate));
    }
}