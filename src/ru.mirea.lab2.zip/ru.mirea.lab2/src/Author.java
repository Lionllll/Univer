public class Author {
    // Поля класса
    private String name;
    private String email;
    private char gender; // 'M', 'F', 'U'

    // Конструктор
    public Author(String name, String email, char gender) {
        this.name = name;
        this.email = email;
        this.gender = gender;
    }

    // Геттер для имени
    public String getName() {
        return name;
    }

    // Геттер для электронной почты
    public String getEmail() {
        return email;
    }

    // Сеттер для электронной почты
    public void setEmail(String email) {
        this.email = email;
    }

    // Геттер для пола
    public char getGender() {
        return gender;
    }

    // Метод ToString
    @Override
    public String toString() {
        String genderStr;
        switch (gender) {
            case 'M':
                genderStr = "m";
                break;
            case 'F':
                genderStr = "f";
                break;
            case 'U':
                genderStr = "u";
                break;
            default:
                genderStr = "u"; // На случай некорректного значения
        }
        return name + " (" + genderStr + ") at " + email;
    }
}