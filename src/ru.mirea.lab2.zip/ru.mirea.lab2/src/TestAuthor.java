public class TestAuthor {
    public static void main(String[] args) {
        // Создаем экземпляры класса Author
        Author author1 = new Author("Tan Ah Teck", "ahTeck@somewhere.com", 'M');
        Author author2 = new Author("Sue Grant", "suGrant@somewhere.com", 'F');

        // Выводим информацию об авторах
        System.out.println(author1);
        System.out.println(author2);

        // Тестируем метод setEmail
        author1.setEmail("newEmail@somewhere.com");
        System.out.println("Updated Email: " + author1.getEmail());

        // Проверяем, что имя и пол не могут быть изменены (сеттеров нет)
        System.out.println("Name: " + author1.getName());
        System.out.println("Gender: " + author1.getGender());
    }
}